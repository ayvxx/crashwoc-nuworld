﻿param([string]$Exe)
$ErrorActionPreference = 'Stop'
$showDialog = !$Exe

function Show-CocoSuccess([string]$Message) {
    Write-Host $Message
    if ($showDialog) {
        $body = $Message + [Environment]::NewLine + [Environment]::NewLine + 'Press Enter or click OK to close.'
        [void][System.Windows.Forms.MessageBox]::Show(
            $body, 'Success - Coco Patcher',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)
    }
}

if (!$Exe) {
    Add-Type -AssemblyName System.Windows.Forms
    $picker = New-Object System.Windows.Forms.OpenFileDialog
    try {
        $picker.Title = 'Choose your stock NuWorld.exe'
        $picker.Filter = 'NuWorld.exe|NuWorld.exe'
        if ($picker.ShowDialog() -ne 'OK') { exit 2 }
        $Exe = $picker.FileName
    } finally { $picker.Dispose() }
}

$target = Get-Item -LiteralPath $Exe
if ($target.PSIsContainer -or $target.Name -ine 'NuWorld.exe') { throw 'Choose the NuWorld.exe in your game folder.' }
$folder = $target.DirectoryName
$manifest = Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') | ConvertFrom-Json
$exeHash = (Get-FileHash -LiteralPath $target.FullName).Hash
$patchedHash = ($manifest.files | Where-Object name -eq 'NuWorld.exe').hash
if ($exeHash -notin $manifest.stock -and $exeHash -ne $patchedHash) {
    throw "Unsupported executable. This package supports $($manifest.release) with the approved hashes in manifest.json. Your game folder was not modified. SHA-256: $exeHash"
}
$pending = @()
foreach ($file in $manifest.files) {
    $source = Join-Path (Join-Path $PSScriptRoot 'payload') $file.name
    $destination = Join-Path $folder $file.name
    if ((Get-FileHash -LiteralPath $source).Hash -ne $file.hash) { throw "Damaged payload: $($file.name)." }
    $exists = Test-Path -LiteralPath $destination
    if ($exists -and (Get-FileHash -LiteralPath $destination).Hash -eq $file.hash) { continue }
    $pending += [pscustomobject]@{Name=$file.name; Source=$source; Destination=$destination; Exists=$exists}
}
if (!$pending.Count) { Show-CocoSuccess 'The Coco patch is already installed.'; return }

$backup = Join-Path $folder ('Coco backup ' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup | Out-Null
$applied = @()
try {
    foreach ($file in $pending) {
        Copy-Item -LiteralPath $file.Source -Destination (Join-Path $backup ($file.Name + '.new'))
    }
    foreach ($file in ($pending | Sort-Object { $_.Name -eq 'NuWorld.exe' })) {
        $incoming = Join-Path $backup ($file.Name + '.new')
        if ($file.Exists) {
            [IO.File]::Replace($incoming, $file.Destination, (Join-Path $backup $file.Name))
        } else {
            [IO.File]::Move($incoming, $file.Destination)
        }
        $applied += $file
    }
} catch {
    $failure = $_
    foreach ($file in $applied) {
        if ($file.Exists) {
            [IO.File]::Replace((Join-Path $backup $file.Name), $file.Destination, $null)
        } else {
            Remove-Item -LiteralPath $file.Destination
        }
    }
    throw $failure
}
Write-Host "Originals are in $backup"
Show-CocoSuccess "The Coco patch was applied successfully."
