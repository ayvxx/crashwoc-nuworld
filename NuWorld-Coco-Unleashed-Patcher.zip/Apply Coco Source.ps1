param([Parameter(Mandatory=$true)][string]$Source)
$ErrorActionPreference = 'Stop'
$sourcePath = (Resolve-Path -LiteralPath $Source).Path
$git = Get-Command git -CommandType Application | Select-Object -First 1
$patch = Join-Path $PSScriptRoot 'NuWorld-Coco-Unleashed.patch'
if (!(Test-Path -LiteralPath (Join-Path $sourcePath 'cmake/decomp.cmake'))) {
    throw 'Choose the root of a NuWorld source checkout.'
}
& $git.Source -C $sourcePath apply --check --whitespace=nowarn $patch
if ($LASTEXITCODE -ne 0) { throw 'The patch did not apply cleanly. No files were changed. This revision needs a source merge.' }
& $git.Source -C $sourcePath apply --whitespace=nowarn $patch
if ($LASTEXITCODE -ne 0) { throw 'Git could not apply the source patch.' }
Write-Host 'Coco source applied. Build Windows x64 using the instructions for this NuWorld revision.'
