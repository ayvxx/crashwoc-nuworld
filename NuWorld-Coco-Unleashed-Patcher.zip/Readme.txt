Run Apply Coco Patch.cmd and select NuWorld.exe for the supported 0.10.1 build.
The installer replaces only the executable and backs up the previous one.


For a later release: get its matching NuWorld source checkout and run
powershell -ExecutionPolicy Bypass -File ".\Apply Coco Source.ps1" -Source PATH_TO_CHECKOUT
The script checks the whole patch before applying it. If it applies cleanly,
build Windows x64 with that release's build instructions and test it with its
game files. A clean patch application does not guarantee runtime compatibility.
The included binary installer recognizes known hashes only.

The stock lives icon uses the original eyelid frames from the base Coco model.

Stage model and portrait share the delayed death blink. The closed base-model eyelid glint is removed.
