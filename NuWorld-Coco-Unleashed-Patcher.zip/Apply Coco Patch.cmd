@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Apply-Coco.ps1"
set "result=%errorlevel%"
if "%result%"=="2" exit /b 0
if "%result%"=="0" exit /b 0
echo Patching failed. Check the message above.
pause
exit /b %result%
